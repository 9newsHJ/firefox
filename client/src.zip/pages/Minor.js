import React from "react";
import "../css/Minor.css";
import secondSchedule from "../images/2ndSchedule.jpg";

function Minor() {
  return <img src={secondSchedule} alt="" className="minor" />;
}

export default Minor;

import { createAction } from "@reduxjs/toolkit";

const setNumber = createAction("payprice/setNumber");

export default setNumber;
